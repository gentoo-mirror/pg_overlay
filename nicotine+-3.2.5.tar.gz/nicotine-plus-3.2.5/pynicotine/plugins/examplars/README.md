The plugins in this directory are only meant to be examples of how to do
things. Do NOT install these unless you know what they do and you are okay with
that.
