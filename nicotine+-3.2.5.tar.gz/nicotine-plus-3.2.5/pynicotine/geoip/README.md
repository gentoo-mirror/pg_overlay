# IP2Location Country Database

- Last updated on July 31, 2022
- Original file name "IP2LOCATION-LITE-DB1.BIN" renamed to "ipcountrydb.bin"
- Fetched from https://lite.ip2location.com/database/ip-country

## License

Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
