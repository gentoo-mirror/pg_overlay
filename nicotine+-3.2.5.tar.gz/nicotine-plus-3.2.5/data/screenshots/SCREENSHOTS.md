# Screenshots

[![Search Files](screenshot1.png)](screenshot1.png?raw=1)  
[![Downloads](screenshot2.png)](screenshot2.png?raw=1)  
[![Browse Shares](screenshot3.png)](screenshot3.png?raw=1)
