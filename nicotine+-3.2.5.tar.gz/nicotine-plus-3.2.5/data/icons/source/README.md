# Source files for icons

These are the original SVG source files for Nicotine+ icons, which can be modified in Inkscape. Use these to create minified icons to ship with Nicotine+.

Icons created by mathiascode (released under GPLv3+)
