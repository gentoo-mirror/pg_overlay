---
name: Bug report
about: Something is broken or doesn't work as expected
labels: bug

---

Nicotine+ version:  
Operating System/Distribution:


### Describe the bug


### Expected behavior


### Steps to reproduce the bug


### Additional context
Screenshots, logs, stacktraces or relevant information.
